const mongoose = require('mongoose');

let articleSchmea = mongoose.Schema({
    title: { type: String, require: true },
    content: { type: String, require: true },
    author: { type: mongoose.Schema.Types.ObjectId, required: true, ref: 'User' },
    date: { type: Date, default: Date.now() }
});

const Article = mongoose.model('Article', articleSchmea);

module.exports = Article;